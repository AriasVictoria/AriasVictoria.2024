﻿namespace TrabajoPracticoApi.Dtos
{
    public class DtoAnimal
    {
        public int id { get; set; }
        public string nombreAnimal { get; set; }
        public string raza { get; set; }
        public int edad { get; set; }
        public string sexo { get; set; }
        public string tipoAnimal { get; set; }
        public string dni_persona { get; set; }

    }
}
